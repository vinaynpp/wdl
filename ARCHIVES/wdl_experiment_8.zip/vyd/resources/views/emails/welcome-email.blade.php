@component('mail::message')
# Welcome to VYD

@endcomponent
