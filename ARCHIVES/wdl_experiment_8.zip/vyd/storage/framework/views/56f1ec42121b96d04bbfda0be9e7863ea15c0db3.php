

<?php $__env->startSection('content'); ?>

<div class="container">

<div class="row">
            <div class="col-6 offset-3">

                </a>
            </div>
        </div>
        <div class="row pt-2 pb-4">
            <div class="col-6 offset-3">
                <div>
                    <p>
                    <span class="font-weight-bold">

                    </span>
                    </p>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-12 d-flex justify-content-center">

            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vyd\resources\views/pages/index.blade.php ENDPATH**/ ?>