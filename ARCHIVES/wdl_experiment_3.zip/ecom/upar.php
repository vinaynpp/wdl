<?php
require('connection.inc.php');
require('functions.inc.php');
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>VYD Mart</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">


</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="bich">
    <header>
        <main><img src="photu/VYDMART.png" alt="LOGO"
                style="width:100px;height:100px;">
            VYD MART </main>
        </a>
        <br>
        <br>

        <br>
    </header>
    <h6>
        here are the available books
    </h6>