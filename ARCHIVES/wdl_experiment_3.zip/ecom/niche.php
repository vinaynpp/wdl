<footer>
    <div>
        <p>Copyright© <a href="http://vinaypanchal.com/">VINAY PANCHAL</a> All right reserved.</p>

    </div>

</footer>

</div>


</body>

</html>