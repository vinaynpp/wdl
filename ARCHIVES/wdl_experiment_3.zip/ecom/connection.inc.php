<?php
session_start();
$con=mysqli_connect("localhost","root","","ecom");
define('SITE_PATH','http://localhost/ecom/');
define('PRODUCT_IMAGE_SITE_PATH', SITE_PATH.'photu/');
?>
