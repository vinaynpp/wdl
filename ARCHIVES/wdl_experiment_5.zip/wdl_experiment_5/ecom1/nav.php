<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>

		VYD MART
	</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="boss/bstyle.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
		body {
			margin: 0;
		}

		ul {
			list-style-type: none;
			margin: 0;
			padding: 0;
			overflow: hidden;
			background-color: #333;
			position: fixed;
			top: 0;
			width: 100%;
		}

		li {
			float: left;
		}

		li a {
			display: block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
		}

		li a:hover:not(.active) {
			background-color: #111;
		}

		.active {
			background-color: #4CAF50;
		}
	</style>
</head>

<body>
	<ul>
		<li><a class="active" href="index.php">HOME</a></li>
		<li><a href="boss/index.php">ADMIN</a></li>
		<li><a href="baar.php">LOGOUT</a></li>
		<li><a href="register.php">REGISTER</a></li>

	</ul>

	<h1>
		<br><br>
	</h1>